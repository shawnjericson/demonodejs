// modules/userService.js
// "Nhạc trưởng": gộp validate + kiểm tra trùng + hash + lưu file lại với nhau

const { v4: uuidv4 } = require('uuid');
const { hashPassword } = require('./passwordUtils');
const { isValidFullName, isValidUsername, isValidPassword } = require('./validators');
const { findUserByUsername, saveUser } = require('./fileStorage');

/**
 * Đăng ký user mới
 * @param {{fullName: string, username: string, password: string}} input
 * @returns {{success: boolean, message: string, user?: object}}
 */
function registerUser({ fullName, username, password }) {
  // 1. Validate họ tên
  if (!isValidFullName(fullName)) {
    return { success: false, message: 'Họ tên không được để trống.' };
  }

  // 2. Validate định dạng tài khoản
  if (!isValidUsername(username)) {
    return {
      success: false,
      message: 'Tài khoản chỉ gồm chữ/số/dấu gạch dưới, dài 3-20 ký tự.',
    };
  }

  // 3. Kiểm tra tài khoản đã tồn tại chưa
  if (findUserByUsername(username.trim())) {
    return { success: false, message: `Tài khoản "${username}" đã tồn tại.` };
  }

  // 4. Validate mật khẩu
  if (!isValidPassword(password)) {
    return {
      success: false,
      message: 'Mật khẩu tối thiểu 6 ký tự, phải có cả chữ và số.',
    };
  }

  // 5. Tạo user mới: sinh id ngẫu nhiên bằng uuid, hash mật khẩu
  const newUser = {
    id: uuidv4(),
    fullName: fullName.trim(),
    username: username.trim(),
    password: hashPassword(password),
    createdAt: new Date().toISOString(),
  };

  // 6. Lưu vào file
  saveUser(newUser);

  return {
    success: true,
    message: 'Đăng ký thành công!',
    user: {
      id: newUser.id,
      fullName: newUser.fullName,
      username: newUser.username,
    },
  };
}

module.exports = { registerUser };
