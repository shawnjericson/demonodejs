// modules/passwordUtils.js
// Dùng module "crypto" có sẵn của Node.js để hash mật khẩu (không lưu plain text)

const crypto = require('crypto');

// Hash mật khẩu: sinh salt ngẫu nhiên rồi hash bằng scrypt
// Kết quả lưu dạng "salt:hash" để sau này verify lại được
function hashPassword(plainPassword) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(plainPassword, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

// So sánh mật khẩu người dùng nhập với mật khẩu đã hash lưu trong file
// (dùng cho chức năng đăng nhập sau này)
function verifyPassword(plainPassword, storedHash) {
  const [salt, originalHash] = storedHash.split(':');
  const hash = crypto.scryptSync(plainPassword, salt, 64).toString('hex');
  return hash === originalHash;
}

module.exports = {
  hashPassword,
  verifyPassword,
};
