// modules/fileStorage.js
// Chịu trách nhiệm đọc/ghi dữ liệu user xuống file (.json)

const fs = require('fs');
const path = require('path');

const DATA_FILE = path.join(__dirname, '..', 'data', 'users.json');

// Đảm bảo file data tồn tại, nếu chưa có thì tạo mới với mảng rỗng
function ensureDataFile() {
  if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(DATA_FILE, '[]', 'utf-8');
  }
}

// Đọc toàn bộ danh sách user từ file
function readUsers() {
  ensureDataFile();
  const raw = fs.readFileSync(DATA_FILE, 'utf-8');
  try {
    return JSON.parse(raw);
  } catch (err) {
    // Nếu file bị lỗi/rỗng bất thường thì coi như chưa có user nào
    return [];
  }
}

// Ghi đè toàn bộ danh sách user xuống file
function writeUsers(users) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(users, null, 2), 'utf-8');
}

// Thêm 1 user mới vào file
function saveUser(user) {
  const users = readUsers();
  users.push(user);
  writeUsers(users);
}

// Tìm user theo username (dùng để kiểm tra tài khoản đã tồn tại chưa)
function findUserByUsername(username) {
  const users = readUsers();
  return users.find((u) => u.username === username);
}

module.exports = {
  readUsers,
  writeUsers,
  saveUser,
  findUserByUsername,
};
