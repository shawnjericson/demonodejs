# register-app

Bài tập Node.js: đăng ký tài khoản, validate, hash mật khẩu, sinh id bằng uuid, lưu vào file JSON.

## Cấu trúc thư mục

```
register-app/
├── index.js                  # Điểm khởi chạy, nhận input từ console (readline)
├── package.json
├── data/
│   └── users.json            # Nơi lưu danh sách user
└── modules/
    ├── validators.js         # Validate họ tên / username / password
    ├── passwordUtils.js      # Hash & verify mật khẩu (crypto.scrypt)
    ├── fileStorage.js        # Đọc/ghi file users.json
    └── userService.js        # Gộp các bước lại: check trùng -> validate -> hash -> lưu
```

## Cách chạy

```bash
npm install
npm start
```

Chương trình sẽ hỏi lần lượt: Họ tên, Tài khoản, Mật khẩu, rồi báo kết quả
(thành công / lỗi) và ghi user mới vào `data/users.json`.

## Quy tắc validate hiện tại (có thể chỉnh trong `modules/validators.js`)

- **Họ tên**: không được để trống.
- **Tài khoản**: 3–20 ký tự, chỉ gồm chữ/số/dấu gạch dưới `_`.
- **Mật khẩu**: tối thiểu 6 ký tự, phải có cả chữ và số.
- **Trùng tài khoản**: nếu `username` đã có trong `users.json` thì báo lỗi, không cho đăng ký lại.

## Về hashing

Mật khẩu không lưu dạng plain text. `passwordUtils.js` dùng module `crypto`
có sẵn của Node (không cần cài thêm bcrypt):

- `hashPassword()` sinh salt ngẫu nhiên (16 bytes) rồi hash bằng `scrypt`,
  lưu chung dạng `"salt:hash"`.
- `verifyPassword()` dùng để so khớp lại khi làm chức năng đăng nhập sau này.

## Về uuid

`userService.js` dùng package `uuid` (`uuidv4()`) để sinh `id` ngẫu nhiên,
không trung với chuỗi ngẫu nhiên tự viết tay.

## Gợi ý mở rộng

- Thêm `index-login.js` hoặc hàm `loginUser()` dùng `verifyPassword()` để làm
  tiếp phần đăng nhập.
- Đổi `password` regex trong `validators.js` nếu đề bài yêu cầu quy tắc khác
  (VD: bắt buộc ký tự đặc biệt, viết hoa...).
- Có thể thay `readline` bằng package `inquirer` nếu muốn ẩn ký tự mật khẩu
  khi gõ.
