// modules/validators.js
// Các hàm kiểm tra (validate) dữ liệu người dùng nhập vào

// Họ tên không được để trống
function isValidFullName(fullName) {
  return typeof fullName === 'string' && fullName.trim().length > 0;
}

// Tài khoản: chỉ gồm chữ, số, dấu gạch dưới, dài 3-20 ký tự
function isValidUsername(username) {
  return (
    typeof username === 'string' &&
    /^[a-zA-Z0-9_]{3,20}$/.test(username.trim())
  );
}

// Mật khẩu: tối thiểu 6 ký tự, có ít nhất 1 chữ và 1 số
function isValidPassword(password) {
  return (
    typeof password === 'string' &&
    /^(?=.*[A-Za-z])(?=.*\d).{6,}$/.test(password)
  );
}

module.exports = {
  isValidFullName,
  isValidUsername,
  isValidPassword,
};
