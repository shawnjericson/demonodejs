// index.js - Điểm khởi chạy chương trình
// Nhận Họ tên / Tài khoản / Mật khẩu từ console rồi gọi module xử lý đăng ký

const readline = require('readline');
const { registerUser } = require('./modules/userService');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

function ask(question) {
  return new Promise((resolve) => rl.question(question, resolve));
}

async function main() {
  console.log('=== ĐĂNG KÝ TÀI KHOẢN ===\n');

  const fullName = await ask('Họ tên: ');
  const username = await ask('Tài khoản: ');
  const password = await ask('Mật khẩu: ');

  const result = registerUser({ fullName, username, password });

  if (result.success) {
    console.log(`\n✅ ${result.message}`);
    console.log('Thông tin tài khoản vừa tạo:', result.user);
  } else {
    console.log(`\n❌ ${result.message}`);
  }

  rl.close();
}

main();
